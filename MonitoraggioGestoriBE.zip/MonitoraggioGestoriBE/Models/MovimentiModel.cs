namespace MonitoraggioGestoriBE.Models;

public class MovimentiModel
{
    
}

public class MovimentiNormalizzatiModel
{
    public decimal IdMovimentoNormalizzato { get; set; }
    public string Stato { get; set; }
}